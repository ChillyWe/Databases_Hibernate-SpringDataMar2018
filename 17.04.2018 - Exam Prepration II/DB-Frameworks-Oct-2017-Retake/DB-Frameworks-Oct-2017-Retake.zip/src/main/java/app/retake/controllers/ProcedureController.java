package app.retake.controllers;

import org.springframework.stereotype.Controller;

import javax.xml.bind.JAXBException;
import java.io.IOException;

@Controller
public class ProcedureController {

    public String importDataFromXML(String xmlContent){
        return null;
    }

    public String exportProcedures() throws IOException, JAXBException {
        return null;
    }
}
