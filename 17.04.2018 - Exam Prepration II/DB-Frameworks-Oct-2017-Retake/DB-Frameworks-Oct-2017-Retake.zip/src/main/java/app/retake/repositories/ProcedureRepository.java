package app.retake.repositories;

public interface ProcedureRepository  {
}
