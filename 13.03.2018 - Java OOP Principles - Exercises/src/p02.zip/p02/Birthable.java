package p02;

public interface Birthable {
    String getBirthdate();
}