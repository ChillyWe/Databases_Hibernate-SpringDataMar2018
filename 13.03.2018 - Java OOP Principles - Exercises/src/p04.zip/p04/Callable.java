package p04;

/**
 * Created by Chilly on 18.11.2017 г..
 */
public interface Callable {
    String call(String number);
}