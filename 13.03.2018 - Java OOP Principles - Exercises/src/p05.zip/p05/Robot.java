package p05;

/**
 * Created by Chilly on 19.11.2017 г..
 */
public class Robot extends BaseResident{
    protected Robot(String name, String id) {
        super(name, id);
    }
}