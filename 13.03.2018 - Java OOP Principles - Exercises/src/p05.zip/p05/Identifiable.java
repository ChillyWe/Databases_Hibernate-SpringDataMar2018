package p05;

/**
 * Created by Chilly on 19.11.2017 г..
 */
public interface Identifiable {
    String getId();
}