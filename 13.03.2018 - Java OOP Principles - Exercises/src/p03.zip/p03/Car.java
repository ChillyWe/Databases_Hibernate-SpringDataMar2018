package p03;

/**
 * Created by Chilly on 18.11.2017 г..
 */
public interface Car {
    public String getDriver();

    public String getModel();

    public String useBrakes();

    public String useGasPedal();
}