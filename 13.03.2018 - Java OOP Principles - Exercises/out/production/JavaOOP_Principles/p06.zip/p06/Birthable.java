package p06;

public interface Birthable {
    String getBirthdate();
}