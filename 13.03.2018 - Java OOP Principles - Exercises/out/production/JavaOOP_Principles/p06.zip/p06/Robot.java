package p06;

public class Robot extends BaseResident {
    protected Robot(String name, String id) {
        super(name, id);
    }
}